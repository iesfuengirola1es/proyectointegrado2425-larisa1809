package com.example.travel_new.AllTourAttractions;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.travel_new.R;

import java.util.ArrayList;
public class TourAttractionsList extends AppCompatActivity {
    RecyclerView recycler;
    LinearLayoutManager manager;
    TourAttractionsList_Adapter adapter;
    ArrayList<TourAttractionsList_Model> array;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_attractions_list);

        array = new ArrayList<>();
        array.add(new TourAttractionsList_Model("Agra", "Uttar Pradesh", R.drawable.agra));
        array.add(new TourAttractionsList_Model("Amritsar", "Punjab", R.drawable.amritsar));
        array.add(new TourAttractionsList_Model("Darjeeling", "West Bengal", R.drawable.darjeeling));
        array.add(new TourAttractionsList_Model("Jaipur", "Rajasthan", R.drawable.jaipur));
        array.add(new TourAttractionsList_Model("Kolkata", "West Bengal", R.drawable.kolkata));
        array.add(new TourAttractionsList_Model("Mumbai", "Maharashtra", R.drawable.mumbai));
        array.add(new TourAttractionsList_Model("Mysore", "Karnataka", R.drawable.mysore));
        array.add(new TourAttractionsList_Model("New Delhi", "Delhi", R.drawable.delhi));
        array.add(new TourAttractionsList_Model("Udaipur", "Rajasthan", R.drawable.udaipur));
        array.add(new TourAttractionsList_Model("Varanasi", "Uttar Pradesh", R.drawable.varanasi));

        adapter = new TourAttractionsList_Adapter(this, array);

        manager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);

        recycler = findViewById(R.id.tourattr_recycler);
        recycler.setAdapter(adapter);
        recycler.setLayoutManager(manager);

    }
}
